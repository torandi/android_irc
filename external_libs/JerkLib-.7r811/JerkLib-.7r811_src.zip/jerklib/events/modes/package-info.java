/**
 * 
 * Package contains classes for ModeEvents 
 * 
 */

package jerklib.events.modes;
