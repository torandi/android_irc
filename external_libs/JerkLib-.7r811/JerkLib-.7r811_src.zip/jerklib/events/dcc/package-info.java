/**
 * 
 * Package contains all the DCC event interfaces
 */

package jerklib.events.dcc;
