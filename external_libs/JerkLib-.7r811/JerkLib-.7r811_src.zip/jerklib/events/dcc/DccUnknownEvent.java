package jerklib.events.dcc;

/**
 * DCC event that couldn't be categorized.
 * 
 * @author Andres N. Kievsky
 */
public interface DccUnknownEvent extends DccEvent
{
}
