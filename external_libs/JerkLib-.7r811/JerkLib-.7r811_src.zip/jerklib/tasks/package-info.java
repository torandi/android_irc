/**
 * 
 * Package contains the Task interface and a Task impl
 * 
 */

package jerklib.tasks;
