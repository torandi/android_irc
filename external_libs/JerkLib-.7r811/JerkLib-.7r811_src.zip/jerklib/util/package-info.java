/**
 * 
 * Package contains utilites for working with JerkLib and IRC in general
 * 
 */

package jerklib.util;
